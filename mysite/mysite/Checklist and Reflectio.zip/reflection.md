# Reflection

Setting up the environment for this project was a bit challenging at first. The first issue I faced was checking the correct Python version. At the beginning, I had an older version, so I had to update it to make sure it would work with Django. After that, I also needed to make sure that the virtual environment was active, which was confusing at first, but I learned how to activate it properly.

Another challenge was installing Django and making sure the `runserver` command worked. At first, I got errors because some packages were missing. I solved this by carefully following the installation steps and using `pip install` to get the needed dependencies. Once everything was set, I was able to run the server without problems.

Lastly, setting up Git with the remote repository took some time. I had to learn the proper commands to add a remote and push my files. In the end, I was able to finish everything, and the process helped me understand the setup better.
